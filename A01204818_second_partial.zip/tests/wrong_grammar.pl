$foo = 5
while(== $foo 6){
  print($foo)
}
