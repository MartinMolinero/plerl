$three = 3
