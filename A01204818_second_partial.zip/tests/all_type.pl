$foo = true
$foo = false
$foo = 10
$foo = 10.89
$foo = "enemy"
