@
"this is a sample " = use => $foo 4
