use constant myconstant => 3
