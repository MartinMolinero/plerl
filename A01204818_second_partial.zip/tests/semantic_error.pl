$variable = "i want to add a string plus a number" + 4.0
print((TRUE + 2))
print(TRUE)
$VAR = 2 + 3
