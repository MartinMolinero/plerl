
use constant thisconstant => 8
$foo =  2 + 2
$foo++
#this is a comment
while($foo > thisconstant){
  print($foo)
  $foo--
}

$variable = true

if($variable){
  print("hola")
}
#wbu
