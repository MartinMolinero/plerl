/*
this is
a multicomment line
*/
#single comment line
use thisconstant => 8
$foo = 12
while($foo > thisconstant){
  print $foo
  $foo--
}

$variable = true

if($variable){
  print "hola"
}
