$foo = "this is a string"
