use myconstant => 3
