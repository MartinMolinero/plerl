$foo = <STDIN>
print($foo)
