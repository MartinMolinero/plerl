$foo = 5
while($foo > 0 ){
  print($foo++)
  if ($foo == 1){
    print($foo)
  }
  $foo--
}
